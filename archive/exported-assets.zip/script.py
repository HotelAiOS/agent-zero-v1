
# GENEROWANIE PLIKÓW Z POPRAWNYMI NAZWAMI
import os

# Usuń stare pliki jeśli istnieją
old_files = [
    'neo4j_client_fixed.py',
    'agent_executor_fixed.py', 
    'task_decomposer_fixed.py',
    'docker-compose_fixed.yml'
]

for f in old_files:
    if os.path.exists(f):
        os.remove(f)
        print(f"🗑️ Removed old file: {f}")

print("\n" + "="*80)
print("GENERATING CORRECT FILES")
print("="*80 + "\n")

# 1. neo4j_client.py
neo4j_code = '''"""
Neo4j Knowledge Graph Client - FIXED VERSION
Agent Zero V1 - Critical Fix A0-5

Fixes:
- Connection retry logic with exponential backoff
- Proper connection pooling
- Health check mechanism
- Comprehensive error handling
"""

import os
import time
import logging
from typing import Optional, Dict, Any, List
from neo4j import GraphDatabase
from neo4j.exceptions import ServiceUnavailable, AuthError

logger = logging.getLogger(__name__)


class Neo4jClient:
    """Enhanced Neo4j client with robust connection handling"""
    
    def __init__(
        self,
        uri: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        max_retries: int = 5,
        retry_delay: float = 2.0
    ):
        """Initialize Neo4j client with retry logic"""
        self.uri = uri or os.getenv("NEO4J_URI", "bolt://localhost:7687")
        self.username = username or os.getenv("NEO4J_USERNAME", "neo4j")
        self.password = password or os.getenv("NEO4J_PASSWORD", "agent-pass")
        
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.driver = None
        
        self._connect_with_retry()
    
    def _connect_with_retry(self) -> None:
        """Establish connection with exponential backoff retry"""
        for attempt in range(1, self.max_retries + 1):
            try:
                logger.info(f"Neo4j connection attempt {attempt}/{self.max_retries}")
                
                self.driver = GraphDatabase.driver(
                    self.uri,
                    auth=(self.username, self.password),
                    max_connection_pool_size=50,
                    connection_timeout=30.0,
                    max_transaction_retry_time=15.0
                )
                
                # Verify connection
                self.driver.verify_connectivity()
                logger.info(f"✅ Neo4j connected successfully to {self.uri}")
                return
                
            except ServiceUnavailable as e:
                logger.warning(f"Neo4j service unavailable (attempt {attempt}): {e}")
                
                if attempt < self.max_retries:
                    delay = self.retry_delay * (2 ** (attempt - 1))
                    logger.info(f"Retrying in {delay:.1f} seconds...")
                    time.sleep(delay)
                else:
                    logger.error("❌ Neo4j connection failed after all retries")
                    raise ConnectionError(
                        f"Failed to connect to Neo4j at {self.uri} after {self.max_retries} attempts"
                    )
            
            except AuthError as e:
                logger.error(f"❌ Neo4j authentication failed: {e}")
                raise ValueError(f"Invalid Neo4j credentials for {self.username}")
            
            except Exception as e:
                logger.error(f"❌ Unexpected Neo4j connection error: {e}")
                raise
    
    def health_check(self) -> Dict[str, Any]:
        """Check Neo4j database health"""
        try:
            with self.driver.session() as session:
                result = session.run("CALL dbms.components() YIELD versions RETURN versions")
                versions = result.single()
                
                return {
                    "status": "healthy",
                    "uri": self.uri,
                    "versions": versions[0] if versions else [],
                    "connected": True
                }
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return {
                "status": "unhealthy",
                "uri": self.uri,
                "error": str(e),
                "connected": False
            }
    
    def execute_query(
        self,
        query: str,
        parameters: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """Execute Cypher query with error handling"""
        if not self.driver:
            raise RuntimeError("Neo4j driver not initialized")
        
        try:
            with self.driver.session() as session:
                result = session.run(query, parameters or {})
                return [record.data() for record in result]
        
        except ServiceUnavailable:
            logger.error("Neo4j service unavailable, attempting reconnection...")
            self._connect_with_retry()
            with self.driver.session() as session:
                result = session.run(query, parameters or {})
                return [record.data() for record in result]
        
        except Exception as e:
            logger.error(f"Query execution failed: {e}")
            logger.error(f"Query: {query}")
            logger.error(f"Parameters: {parameters}")
            raise
    
    def close(self) -> None:
        """Close database connection"""
        if self.driver:
            self.driver.close()
            logger.info("Neo4j connection closed")


# Singleton instance
_neo4j_client: Optional[Neo4jClient] = None


def get_neo4j_client() -> Neo4jClient:
    """Get or create Neo4j client singleton"""
    global _neo4j_client
    
    if _neo4j_client is None:
        _neo4j_client = Neo4jClient()
    
    return _neo4j_client
'''

with open('neo4j_client.py', 'w', encoding='utf-8') as f:
    f.write(neo4j_code)
print("✅ Generated: neo4j_client.py")

# 2. agent_executor.py
executor_code = '''"""
Agent Executor - FIXED VERSION
Agent Zero V1 - Critical Fix A0-6

Fixes:
- Standardized execute_task() method signature
- Proper type hints and validation
- Enhanced error handling
- Async support
"""

import asyncio
import logging
from typing import Dict, Any, Optional, Callable
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class TaskStatus(Enum):
    """Task execution status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class ExecutionContext:
    """Context for task execution"""
    task_id: str
    agent_type: str
    input_data: Dict[str, Any]
    workspace_dir: str
    timeout: Optional[int] = 300
    metadata: Optional[Dict[str, Any]] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


@dataclass
class ExecutionResult:
    """Result of task execution"""
    task_id: str
    status: TaskStatus
    output: Optional[Any] = None
    error: Optional[str] = None
    execution_time: float = 0.0
    metadata: Optional[Dict[str, Any]] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}
    
    @property
    def is_success(self) -> bool:
        return self.status == TaskStatus.COMPLETED


class AgentExecutor:
    """Enhanced Agent Executor with standardized interface"""
    
    def __init__(self, agent_registry: Optional[Dict] = None):
        self.agent_registry = agent_registry or {}
        self.active_tasks: Dict[str, asyncio.Task] = {}
        logger.info("AgentExecutor initialized")
    
    async def execute_task(
        self,
        context: ExecutionContext,
        callback: Optional[Callable] = None
    ) -> ExecutionResult:
        """Execute agent task with standardized interface"""
        import time
        start_time = time.time()
        
        logger.info(f"Executing task {context.task_id} with agent {context.agent_type}")
        
        if context.agent_type not in self.agent_registry:
            error_msg = f"Agent type '{context.agent_type}' not registered"
            logger.error(error_msg)
            return ExecutionResult(
                task_id=context.task_id,
                status=TaskStatus.FAILED,
                error=error_msg,
                execution_time=time.time() - start_time
            )
        
        try:
            agent = self.agent_registry[context.agent_type]
            
            task = asyncio.create_task(
                self._execute_with_timeout(agent, context, callback)
            )
            self.active_tasks[context.task_id] = task
            
            result = await task
            result.execution_time = time.time() - start_time
            
            logger.info(f"✅ Task {context.task_id} completed in {result.execution_time:.2f}s")
            return result
        
        except asyncio.TimeoutError:
            error_msg = f"Task execution timed out after {context.timeout}s"
            logger.error(error_msg)
            return ExecutionResult(
                task_id=context.task_id,
                status=TaskStatus.FAILED,
                error=error_msg,
                execution_time=time.time() - start_time
            )
        
        except Exception as e:
            error_msg = f"Task execution failed: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return ExecutionResult(
                task_id=context.task_id,
                status=TaskStatus.FAILED,
                error=error_msg,
                execution_time=time.time() - start_time
            )
        
        finally:
            if context.task_id in self.active_tasks:
                del self.active_tasks[context.task_id]
    
    async def _execute_with_timeout(
        self,
        agent: Any,
        context: ExecutionContext,
        callback: Optional[Callable]
    ) -> ExecutionResult:
        """Execute agent task with timeout"""
        
        if callback:
            callback(context.task_id, TaskStatus.RUNNING)
        
        try:
            if asyncio.iscoroutinefunction(agent.execute):
                output = await asyncio.wait_for(
                    agent.execute(context.input_data, context.workspace_dir),
                    timeout=context.timeout
                )
            else:
                output = await asyncio.wait_for(
                    asyncio.to_thread(
                        agent.execute,
                        context.input_data,
                        context.workspace_dir
                    ),
                    timeout=context.timeout
                )
            
            if callback:
                callback(context.task_id, TaskStatus.COMPLETED)
            
            return ExecutionResult(
                task_id=context.task_id,
                status=TaskStatus.COMPLETED,
                output=output
            )
        
        except Exception as e:
            if callback:
                callback(context.task_id, TaskStatus.FAILED)
            raise
    
    def register_agent(self, agent_type: str, agent_instance: Any) -> None:
        """Register agent implementation"""
        self.agent_registry[agent_type] = agent_instance
        logger.info(f"Registered agent: {agent_type}")
'''

with open('agent_executor.py', 'w', encoding='utf-8') as f:
    f.write(executor_code)
print("✅ Generated: agent_executor.py")

print("\n✨ Files generated with CORRECT names!")
print("\nNext: Generating task_decomposer.py and docker-compose.yml...")
